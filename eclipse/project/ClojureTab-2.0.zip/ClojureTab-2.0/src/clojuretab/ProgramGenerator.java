/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package clojuretab;

import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protege.model.KnowledgeBase;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/**
 *
 * @author ru
 */
public class ProgramGenerator {

    public static String FILE_SEPARATOR = System.getProperty("file.separator");
    public static String SOURCE_FOLDER = "src"+FILE_SEPARATOR+"clojure";

    static KnowledgeBase kb;

    String name;
    String folder;
    Instance namespace;
    Collection<Instance> vars;
    Collection<Instance> funcs;
    Collection<Instance> protos;
    Collection<Instance> types;
    Collection<Instance> recs;
	Collection<Instance> extypes;
    Collection<Instance> exprotos;
    static List<String> func_lines;
    static Object theme;
    static Object font;
    static Object width;
    static Object height;
    
    @SuppressWarnings("unchecked")
	public ProgramGenerator(Instance prog) {
        kb = prog.getKnowledgeBase();
        // Program properties
        namespace = (Instance) prog.getOwnSlotValue(kb.getSlot(Ontology.NAMESPACE_S));
        setFolderAndName((String) namespace.getOwnSlotValue(kb.getSlot(Ontology.TITLE)));
        vars = prog.getOwnSlotValues(kb.getSlot(Ontology.VARS));
        funcs = prog.getOwnSlotValues(kb.getSlot(Ontology.FUNCTIONS));
        protos = prog.getOwnSlotValues(kb.getSlot(Ontology.PROTOCOLS));
        types = prog.getOwnSlotValues(kb.getSlot(Ontology.TYPES));
        recs = prog.getOwnSlotValues(kb.getSlot(Ontology.RECORDS));
        extypes = prog.getOwnSlotValues(kb.getSlot(Ontology.EXTEND_TYPES));
        exprotos = prog.getOwnSlotValues(kb.getSlot(Ontology.EXTEND_PROTOCOLS));
        // Editor properties
        theme = prog.getOwnSlotValue(kb.getSlot(Ontology.THEME));
        font = prog.getOwnSlotValue(kb.getSlot(Ontology.FONTSIZE));
        width = prog.getOwnSlotValue(kb.getSlot(Ontology.EDITOR_WIDTH));
        height = prog.getOwnSlotValue(kb.getSlot(Ontology.EDITOR_HEIGHT));
    }
    
    public static List<String> getFunc_lines() {
		return func_lines;
	}

    private void setFolderAndName(String ns){
        String[] s = ns.split("\\.");
        name = s[s.length-1];
        folder = "";
        for (int i = 0; i < s.length-1; i++) {
            folder += s[i]+FILE_SEPARATOR;
        }
    }

    public String generateFile(){
    	String prog_folder_pth = SOURCE_FOLDER+FILE_SEPARATOR+folder;
    	String prog_file_pth = prog_folder_pth+name+".clj";
        FileWriter fr = null;
        try {
            File sorfold = new File(prog_folder_pth);
            if(!sorfold.exists())
                sorfold.mkdirs();
            fr = new FileWriter(prog_file_pth);
            generateProgram(fr);
            fr.close();
            return prog_file_pth;
        } catch (IOException ex) {
            Logger.getLogger(ProgramGenerator.class.getName()).log(Level.SEVERE, null, ex);
            try {
                fr.close();
                return null;
            } catch (IOException ex2) {
                Logger.getLogger(ProgramGenerator.class.getName()).log(Level.SEVERE, null, ex2);
                return null;
            }
        }
    }
    
    int ln = 1;

    public void generateProgram(Writer wr) throws IOException{
        genNamespace(wr);
        genVars(wr);
        genProtos(wr);
        genTypesRecs(wr, types, "deftype");
        genTypesRecs(wr, recs, "defrecord");
        genFuncs(wr);
        genExtendes(wr, exprotos, "extend-protocol");
        genExtendes(wr, extypes, "extend-type");
    }

    public String getName() {
        return name;
    }
    
    private void genNamespace(Writer wr) throws IOException{
        String nsc = (String) namespace.getOwnSlotValue(kb.getSlot(Ontology.TITLE));
        String src = (String) namespace.getOwnSlotValue(kb.getSlot(Ontology.SOURCE));
        src = "(ns "+nsc+"\n"+(src==null ? "" : src)+")\n\n";
        wr.write(src);
        ln += numberOfLines(src, 0);
    }

    private void genVars(Writer wr) throws IOException{
        for (Instance instance : vars) {
            String nam = (String) instance.getOwnSlotValue(kb.getSlot(Ontology.TITLE));
            String src = (String) instance.getOwnSlotValue(kb.getSlot(Ontology.SOURCE));
            src = "(def "+nam+" "+(src==null ? "" : src)+")\n\n";
            wr.write(src);
            ln += numberOfLines(src, 0);
        }
    }

    @SuppressWarnings("unchecked")
	private void genTypesRecs(Writer wr, Collection<Instance> whom, String what) throws IOException{
        for (Instance instance : whom) {
            String nam = (String) instance.getOwnSlotValue(kb.getSlot(Ontology.TITLE));
            Collection<String> fls = instance.getOwnSlotValues(kb.getSlot(Ontology.FIELDS));
            Collection<Instance> ops = instance.getOwnSlotValues(kb.getSlot(Ontology.OPTIONS));
            Collection<Instance> pts = instance.getOwnSlotValues(kb.getSlot(Ontology.PROTOCOLS));
            String src = "("+what+" "+nam+" [";
            for (String fld : fls) {
                src += fld+" ";
            }
            src += "]\n";
            for (Instance opt : ops) {
            	String kw = (String) opt.getOwnSlotValue(kb.getSlot(Ontology.KEYWORD));
            	String ar = (String) opt.getOwnSlotValue(kb.getSlot(Ontology.ARGUMENT));
            	src += "\t"+kw+" "+ar+"\n";
            }
            for (Instance ptc : pts) {
            	String tit = (String) ptc.getOwnSlotValue(kb.getSlot(Ontology.TITLE));
            	src += "\t"+tit+"\n";
                Collection<Instance> fns = ptc.getOwnSlotValues(kb.getSlot(Ontology.FUNCTIONS));
                for (Instance ins : fns) {
                    String sig = (String) ins.getOwnSlotValue(kb.getSlot(Ontology.TITLE));
                    String sr = (String) ins.getOwnSlotValue(kb.getSlot(Ontology.SOURCE));
                    src += "\t("+sig+" "+sr+")\n";
                }
            }
            src += ")\n\n";
            wr.write(src);
            ln += numberOfLines(src, 0);
        }
    }

    @SuppressWarnings("unchecked")
	private void genExtendes(Writer wr, Collection<Instance> whom, String what) throws IOException{
        for (Instance instance : whom) {
            String nam = (String) instance.getOwnSlotValue(kb.getSlot(Ontology.TITLE));
            Collection<Instance> ims = instance.getOwnSlotValues(kb.getSlot(Ontology.IMPLEMENTATIONS));
            String src = "("+what+" "+nam+"\n";
            for (Instance inst : ims) {
                String pro = (String) inst.getOwnSlotValue(kb.getSlot(Ontology.TITLE));
                src += "\t"+pro+"\n";
                Collection<Instance> fns = inst.getOwnSlotValues(kb.getSlot(Ontology.FUNCTIONS));
                for (Instance ins : fns) {
                    String sig = (String) ins.getOwnSlotValue(kb.getSlot(Ontology.TITLE));
                    String sr = (String) ins.getOwnSlotValue(kb.getSlot(Ontology.SOURCE));
                    src += "\t("+sig+" "+sr+")\n";
                }
            }
            src += ")\n\n";
            wr.write(src);
            ln += numberOfLines(src, 0);
        }
    }

    @SuppressWarnings("unchecked")
	private void genProtos(Writer wr) throws IOException{
        for (Instance instance : protos) {
            String nam = (String) instance.getOwnSlotValue(kb.getSlot(Ontology.TITLE));
            Collection<Instance> fns = instance.getOwnSlotValues(kb.getSlot(Ontology.FUNCTIONS));
            String src = "(defprotocol "+nam+"\n";
            ln++;
            String previous_func = "";
            String signature = null;
            for (Instance inst : fns) {
                String title = (String) inst.getOwnSlotValue(kb.getSlot(Ontology.TITLE));
                String[] tit = title.split("\\[");
                String func = tit[0].trim();
                String[] arg = tit[1].split("\\]");
                if(signature == null) {
                    signature = "\t("+title;
                } else if (previous_func.equals(func)) {
                    signature += " ["+arg[0]+"]";
                } else {
                    src += signature+")\n";
                    signature = "\t("+title;
                }
                previous_func = func;
            }
            src += signature+")\n)\n";
            wr.write(src);
            ln += numberOfLines(src, 0);
        }
    }
    
    private void genFuncs(Writer wr) throws IOException{
    	func_lines = new ArrayList<String>();
        for (Instance instance : funcs) {
            String func = instance.hasDirectType(kb.getCls(Ontology.MACRO)) ? "(defmacro " : "(defn ";
            String tit = (String) instance.getOwnSlotValue(kb.getSlot(Ontology.TITLE));
            String src = (String) instance.getOwnSlotValue(kb.getSlot(Ontology.SOURCE));
            String sign = "";
            String fnam = tit;
            int sign_start = tit.indexOf("[");
            if (sign_start > 0) {
            	fnam = tit.substring(0, sign_start);
            	sign = tit.substring(sign_start);
            }
            String func_src = func+fnam+sign+"\n"+(src==null ? "" : "  "+src)+")\n\n";
            int line_numb = numberOfLines(func_src, 0);
            wr.write(func_src);
            func_lines.add(ln+"--"+(ln + line_numb - 1)+" "+tit);
            instance.setOwnSlotValue(kb.getSlot(Ontology.START_LINE), ln);
            ln += line_numb;
            instance.setOwnSlotValue(kb.getSlot(Ontology.FINISH_LINE), ln - 1);
        }
    }
    
    public static int numberOfLines(String src, int yet) {
    	int idx = src.indexOf("\n");
    	if(idx < 0)
    		return yet;
    	else
    		return numberOfLines(src.substring(idx + 1), yet + 1);
    }
    
    static Map<Instance, SectionEditor> editors = new HashMap<Instance, SectionEditor>();
    
    public static void editFunction(Instance funci) {
    	try {
    		SectionEditor editor = editors.get(funci);
    		editor.toFront();
    	} catch(Exception e) {
	    	String def = funci.hasDirectType(kb.getCls(Ontology.MACRO)) ? "(defmacro " : "(defn ";
	    	String tit = (String) funci.getOwnSlotValue(kb.getSlot(Ontology.TITLE));
	    	String src = (String) funci.getOwnSlotValue(kb.getSlot(Ontology.SOURCE));
	    	int stl = (Integer) funci.getOwnSlotValue(kb.getSlot(Ontology.START_LINE));
	    	int fnl = (Integer) funci.getOwnSlotValue(kb.getSlot(Ontology.FINISH_LINE));
	        String prm = "";
	        String fnm = tit;
	        int prm_start = tit.indexOf("[");
	        if (prm_start > 0) {
	        	fnm = tit.substring(0, prm_start);
	        	prm = tit.substring(prm_start);
	        }
	        String func_src = def+fnm+prm+"\n"+(src==null ? "" : "  "+src)+")\n\n";
	        String thm = (theme==null || ((String) theme).isEmpty() ? "Light"  : (String) theme);
	        int fnt = (font==null ? 14 : (int) font);
	        int wdt = (width==null ? 480 : (int) width);
	        int hgt = (height==null ? 480 : (int) height);
	        SectionEditor editor = new SectionEditor(func_src, "function", tit, stl, fnl, thm, fnt, wdt, hgt);
	        editor.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	        editor.addWindowListener(new WindowAdapter() {
	            @Override
	            public void windowClosing(WindowEvent e) {
	                int confirmed = JOptionPane.showConfirmDialog(editor, 
	                	"Reflect Updates in Ontology?",
	                	"Editors",
	                    JOptionPane.YES_NO_OPTION);
	                Instance key = getLinkedInstance(editor);
	                if (confirmed == JOptionPane.YES_OPTION) {
	                	reflectFunction(key);
	                }
	                editors.remove(key);
	                editor.dispose();
	            }
	        });
	        editors.put(funci, editor);
	        editor.setVisible(true);
	        editor.toFront();
	    }
    }
    
    public static Instance getLinkedInstance(SectionEditor editor) {
    	for(Instance funci : editors.keySet()) {
    		SectionEditor ed = editors.get(funci);
    		if(ed.equals(editor)){
    			return funci;
    		}
    	}
    	return null;
    }
    
    public static void reflectFunction(Instance funci) {
    	SectionEditor editor = editors.get(funci);
    	String txt = editor.getText();
    	int i1 = txt.indexOf("\n");
    	if(i1 > 0) {
    		String def = txt.substring(0, i1);
        	int i2 = def.indexOf(" ");
        	if(i2 > 0) {
	    		String tit = def.substring(i2);
	    		txt = txt.substring(i1+1);
	    		i1 = txt.lastIndexOf(")");
	    		if(i1 >0) {
	    			String src = txt.substring(0, i1);
	    			funci.setOwnSlotValue(kb.getSlot(Ontology.TITLE), tit);
	    			funci.setOwnSlotValue(kb.getSlot(Ontology.SOURCE), src);
	    		}
    		}
    	}
    }
    
    public static void reflectAllFunctions() {
    	for(Instance funci : editors.keySet()) {
    		reflectFunction(funci);
    	}
    }
    
    public static void closeAllEditors() {
    	SwingUtilities.invokeLater(new Runnable() {
            public void run() {
		    	int ans = JOptionPane.showConfirmDialog(
		    			ClojureTab.main_panel,
		            	"Reflect Updates in Ontology?",
		    			"Editors",
		            	JOptionPane.YES_NO_OPTION);
		        if(ans == JOptionPane.YES_OPTION) {
		            reflectAllFunctions();
		        }
		    	for(Instance funci : editors.keySet()) {
		    		SectionEditor editor = editors.get(funci);
		    		editor.dispose();
		    	}
		        editors = new HashMap<Instance, SectionEditor>();
		    }
        });
    }
    
}
