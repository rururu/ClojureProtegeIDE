package clojuretab;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import javax.swing.undo.*;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.regex.*;
import java.awt.*;
import java.awt.event.*;

public class ClojureEditor extends JFrame {
    private static final long serialVersionUID = 1L;

    private final JTextPane editor = new JTextPane();
    private final JTextArea lineNumbers = new JTextArea("1\n");
    private final JPanel top = new JPanel();
    private final JPanel bottom = new JPanel();
    private final JLabel positionLabel = new JLabel("00:00");
    private final JTextField searchField = new JTextField(20);
    private final JButton searchButton = new JButton("Search");
    private final JButton checkBalanceBtn = new JButton("Check balance");
    private JButton configBtn;

    private final UndoManager undoManager = new UndoManager();
    private DocumentListener docListener;
    private Timer highlightTimer = null;

    private final Pattern commentPat = Pattern.compile("(?m);.*$");
    private final Pattern stringPat = Pattern.compile("\"(\\\\.|[^\"\\\\])*\"");
    private final Pattern keywordPat = Pattern.compile("\\b(defn|def|if|let|fn|loop|recur|do|quote|try|catch|finally)\\b");
    private final Pattern numberPat = Pattern.compile("\\b\\d+\\.?\\d*\\b");

    private final Highlighter highlighter = editor.getHighlighter();
    private Object leftParenHighlight = null;
    private Object rightParenHighlight = null;
    
    private int startLineNumber = 1;
    private boolean config = true;
    private boolean darkTheme = false;
    private int fontSize = 14;
    

	public ClojureEditor(String theme, int fontSize) {
        super("Clojure Editor");
    	this.fontSize = fontSize;
        if (theme.equals("Dark"))
        	darkTheme = true;
        config = false;
        mkConstructor();
    }
    
	public ClojureEditor() {
        super("Clojure Editor");
        mkConstructor();
    }

    private void mkConstructor() {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(super.getOwner());

        searchButton.addActionListener(_ -> searchContent(searchField.getText()));
        checkBalanceBtn.addActionListener(_ -> checkBalance());
        top.add(positionLabel);
        top.add(searchField);
        top.add(searchButton);
        top.add(checkBalanceBtn);
        add(top, BorderLayout.NORTH);

        JScrollPane scroll = new JScrollPane(editor);
        scroll.setRowHeaderView(lineNumbers);
        add(scroll, BorderLayout.CENTER);

        if (config) {
            configBtn = new JButton("Config");
            bottom.add(configBtn, BorderLayout.CENTER);
            configBtn.addActionListener(_ -> openConfigDialog());
            add(bottom, BorderLayout.SOUTH);
        }

        editor.setFont(new Font("Monospaced", Font.PLAIN, fontSize));
        lineNumbers.setFont(editor.getFont());
        lineNumbers.setEditable(false);
        lineNumbers.setBackground(new Color(240, 240, 240));
        lineNumbers.setForeground(Color.BLACK);

        highlightTimer = new Timer(300, _ -> highlightAllSafe());
        highlightTimer.setRepeats(false);

        docListener = new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { scheduleHighlight(); updateLineNumbers(); }
            public void removeUpdate(DocumentEvent e) { scheduleHighlight(); updateLineNumbers(); }
            public void changedUpdate(DocumentEvent e) { scheduleHighlight(); updateLineNumbers(); }
        };
        editor.getDocument().addDocumentListener(docListener);

        editor.getDocument().addUndoableEditListener(evt -> undoManager.addEdit(evt.getEdit()));

        InputMap im = editor.getInputMap(JComponent.WHEN_FOCUSED);
        ActionMap am = editor.getActionMap();
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_Z, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()), "undo");
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_Y, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()), "redo");
        am.put("undo", new AbstractAction() { public void actionPerformed(ActionEvent e) { if (undoManager.canUndo()) undoManager.undo(); }});
        am.put("redo", new AbstractAction() { public void actionPerformed(ActionEvent e) { if (undoManager.canRedo()) undoManager.redo(); }});

        // Авто-отступ при Enter
        KeyStroke enter = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0);
        editor.getInputMap().put(enter, "insert-newline-indent");
        editor.getActionMap().put("insert-newline-indent", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int caret = editor.getCaretPosition();
                    Document d = editor.getDocument();
                    int lineStart = Utilities.getRowStart(editor, Math.max(0, caret-1));
                    String prevLine = d.getText(lineStart, Math.max(0, caret - lineStart));
                    StringBuilder indent = new StringBuilder();
                    for (int i = 0; i < prevLine.length(); i++) {
                        char ch = prevLine.charAt(i);
                        if (ch == ' ' || ch == '\t') indent.append(ch); else break;
                    }
                    d.insertString(caret, "\n" + indent.toString(), null);
                    editor.setCaretPosition(caret + 1 + indent.length());
                } catch (BadLocationException ex) { editor.replaceSelection("\n"); }
            }
        });

        // Подсветка парных скобок при движении курсора
        editor.addCaretListener(_ -> highlightParenAtCaret());

        updateLineNumbers();
        highlightAllSafe();
        updateCaretColor();
        updateBackground();
        initCursorPositionListener();
        setVisible(true);
    }
    
	private void initCursorPositionListener() {
        editor.addCaretListener(new CaretListener() {
            @Override
            public void caretUpdate(CaretEvent e) {
                updateCursorPosition();
            }
        });
    }
    
    private void updateCursorPosition() {
        int caretPos = editor.getCaretPosition();

        try {
            int lineStart = Utilities.getRowStart(editor, caretPos);
			int line = editor.getDocument()
                    .getDefaultRootElement()
                    .getElementIndex(caretPos) + startLineNumber;

            int column = caretPos - lineStart + 1;

            positionLabel.setText(String.format("%02d:%02d", line, column));
        } catch (BadLocationException e) {
            positionLabel.setText("??:??");
        }
    }

    private void highlightAllSafe() {
        Document doc = editor.getDocument();
        doc.removeDocumentListener(docListener);
        try {
            highlightAll();
        } finally {
            doc.addDocumentListener(docListener);
        }
    }

    private void highlightAll() {
        StyledDocument doc = editor.getStyledDocument();
        String text = editor.getText();
        if (text.isEmpty()) return;

        // Сброс всех атрибутов
        SimpleAttributeSet normal = new SimpleAttributeSet();
        StyleConstants.setForeground(normal, darkTheme ? new Color(220,220,220) : Color.BLACK);
        StyleConstants.setBold(normal, false);
        doc.setCharacterAttributes(0, text.length(), normal, true);

        // Подсветка элементов
        applyPattern(doc, text, commentPat, createAttr(darkTheme ? Color.CYAN : new Color(0, 88, 0), false), true);
        applyPattern(doc, text, stringPat, createAttr(new Color(255, 128, 0), false), true);
        applyPattern(doc, text, keywordPat, createAttr(darkTheme ? new Color(150, 180, 255) : new Color(0, 0, 255), true), true);
        applyPattern(doc, text, numberPat, createAttr(darkTheme ? Color.MAGENTA : new Color(255, 0, 0), false), true);

        // Все скобки жирные
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (isParen(c)) {
                SimpleAttributeSet parenAttr = new SimpleAttributeSet();
                StyleConstants.setBold(parenAttr, true);
                doc.setCharacterAttributes(i, 1, parenAttr, false);
            }
        }
    }

    private void scheduleHighlight() {
        if (highlightTimer != null) highlightTimer.restart();
    }

    private void applyPattern(StyledDocument doc, String text, Pattern p, AttributeSet style, boolean replace) {
        Matcher m = p.matcher(text);
        while (m.find()) doc.setCharacterAttributes(m.start(), m.end() - m.start(), style, replace);
    }

    private boolean isParen(char c) {
        return c == '(' || c == ')' || c == '[' || c == ']' || c == '{' || c == '}';
    }

    // Подсветка парных скобок с игнорированием строк и комментариев
    private void highlightParenAtCaret() {
        // убрать старую подсветку
        if (leftParenHighlight != null) {
            highlighter.removeHighlight(leftParenHighlight);
            leftParenHighlight = null;
        }
        if (rightParenHighlight != null) {
            highlighter.removeHighlight(rightParenHighlight);
            rightParenHighlight = null;
        }

        String text = editor.getText();
        int caret = editor.getCaretPosition();
        int pos = caret > 0 ? caret - 1 : caret;

        if (pos < 0 || pos >= text.length()) return;

        char ch = text.charAt(pos);
        if (!isParen(ch)) return;
        if (isInsideStringOrComment(text, pos)) return;

        int pairPos = findMatchingParen(text, pos, ch);
        if (pairPos == -1) return;

        boolean leftIsCurrent = (ch == '(' || ch == '[' || ch == '{');
        int leftPos  = leftIsCurrent ? pos : pairPos;
        int rightPos = leftIsCurrent ? pairPos : pos;

        try {
            leftParenHighlight =
                highlighter.addHighlight(
                    leftPos, leftPos + 1,
                    new DefaultHighlighter.DefaultHighlightPainter(new Color(255, 120, 120))
                );

            rightParenHighlight =
                highlighter.addHighlight(
                    rightPos, rightPos + 1,
                    new DefaultHighlighter.DefaultHighlightPainter(new Color(120, 255, 120))
                );
        } catch (BadLocationException ex) {
            // ignore
        }
    }

    private boolean isInsideStringOrComment(String text, int pos) {
        boolean inString = false;
        boolean inComment = false;

        for (int i = 0; i <= pos; i++) {
            char c = text.charAt(i);
            if (!inString && c == ';') inComment = true;
            if (c == '\n') inComment = false;
            if (!inComment && c == '"') {
                if (i == 0 || text.charAt(i-1) != '\\') inString = !inString;
            }
        }
        return inString || inComment;
    }

    private int findMatchingParen(String text, int position, char paren) {
        if (paren == '(' || paren == '[' || paren == '{') return findClosingParen(text, position, paren);
        else return findOpeningParen(text, position, paren);
    }

    private int findClosingParen(String text, int position, char openingParen) {
        char closingParen = openingParen == '(' ? ')' : openingParen == '[' ? ']' : '}';
        int count = 1;
        for (int i = position + 1; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == openingParen) count++;
            if (c == closingParen) count--;
            if (count == 0) return i;
        }
        return -1;
    }

    private int findOpeningParen(String text, int position, char closingParen) {
        char openingParen = closingParen == ')' ? '(' : closingParen == ']' ? '[' : '{';
        int count = 1;
        for (int i = position - 1; i >= 0; i--) {
            char c = text.charAt(i);
            if (c == closingParen) count++;
            if (c == openingParen) count--;
            if (count == 0) return i;
        }
        return -1;
    }

    private void updateLineNumbers() {
        SwingUtilities.invokeLater(() -> {
            int lines = editor.getText().split("\n", -1).length;
            StringBuilder sb = new StringBuilder();
            for (int i = 1; i <= lines; i++) sb.append(i + startLineNumber - 1).append("\n");
            lineNumbers.setText(sb.toString());
        });
    }

    private SimpleAttributeSet createAttr(Color fg, boolean bold) {
        SimpleAttributeSet attr = new SimpleAttributeSet();
        if (fg != null) StyleConstants.setForeground(attr, fg);
        StyleConstants.setBold(attr, bold);
        return attr;
    }

    private void updateCaretColor() {
        editor.setCaretColor(darkTheme ? Color.WHITE : Color.BLACK);
    }

    private void updateBackground() {
        editor.setBackground(darkTheme ? Color.BLACK : Color.WHITE);
    }

    public void searchContent(String query) {
        String editorContent = editor.getText();
        int index = 0;
        boolean found = false;

        editor.setSelectionStart(0);
        editor.setSelectionEnd(0);
        editor.getHighlighter().removeAllHighlights();

        while ((index = editorContent.indexOf(query, index)) != -1) {
            try {
                editor.getHighlighter().addHighlight(index, index + query.length(),
                        new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW));
                Rectangle rect = (Rectangle) editor.modelToView2D(index);
                editor.scrollRectToVisible(rect);
                index += query.length();
                found = true;
            } catch (BadLocationException e) { e.printStackTrace(); }
        }
        if (!found) JOptionPane.showMessageDialog(this, "No match found!");
    }
    

    private boolean isOpenParen(char c) {
        return c == '(' || c == '[' || c == '{';
    }

    private boolean isCloseParen(char c) {
        return c == ')' || c == ']' || c == '}';
    }

    private boolean isMatchingPair(char open, char close) {
        return (open == '(' && close == ')')
            || (open == '[' && close == ']')
            || (open == '{' && close == '}');
    }

    private void checkBalance() {
        String text = editor.getText();

        Deque<Integer> stack = new ArrayDeque<>();

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);

            // игнорируем строки и комментарии
            if (isInsideStringOrComment(text, i)) continue;

            if (isOpenParen(c)) {
                stack.push(i);
            }
            else if (isCloseParen(c)) {

                // ❗ стек пуст — лишняя закрывающая скобка
                if (stack.isEmpty()) {
                    highlightBalanceError(i);
                    continue;
                }

                int openPos = stack.peek();
                char open = text.charAt(openPos);

                if (isMatchingPair(open, c)) {
                    stack.pop();
                } else {
                    // несовпадающая пара
                    highlightBalanceError(i);
                }
            }
        }

        // ❗ оставшиеся в стеке — незакрытые скобки
        while (!stack.isEmpty()) {
            highlightBalanceError(stack.pop());
        }
    }
    
    private void highlightBalanceError(int pos) {
        SimpleAttributeSet err = new SimpleAttributeSet();
        StyleConstants.setBackground(err, new Color(255, 160, 160));
        StyleConstants.setBold(err, true);
        editor.getStyledDocument().setCharacterAttributes(pos, 1, err, false);
    }

    @SuppressWarnings("unused")
	private void openConfigDialog() {
        JDialog dlg = new JDialog(this, "Config", true);
        dlg.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.WEST;

        JCheckBox darkBox = new JCheckBox("Dark theme", darkTheme);
        dlg.add(darkBox, c);

        c.gridy++;
        dlg.add(new JLabel("Font size:"), c);
        JSpinner fontSpinner = new JSpinner(new SpinnerNumberModel(fontSize, 10, 28, 1));
        c.gridx = 1;
        dlg.add(fontSpinner, c);

        c.gridx = 0; c.gridy++;
        JButton apply = new JButton("Apply");
        dlg.add(apply, c);
        JButton close = new JButton("Close");
        c.gridx = 1;
        dlg.add(close, c);

        apply.addActionListener(e -> {
            darkTheme = darkBox.isSelected();
            fontSize = (Integer) fontSpinner.getValue();
            editor.setFont(new Font("Monospaced", Font.PLAIN, fontSize));
            lineNumbers.setFont(editor.getFont());
            highlightAllSafe();
            updateCaretColor();
            updateBackground();
            dlg.dispose();
        });
        close.addActionListener(e -> dlg.dispose());

        dlg.pack();
        dlg.setLocationRelativeTo(this);
        dlg.setVisible(true);
    }
    public void setStartLineNumber(int startLineNumber) {
		this.startLineNumber = startLineNumber;
		lineNumbers.setText(startLineNumber+"\n");
	}
    
	public JPanel getBottom() {
		return bottom;
	}

	public void setText(String text) {
    	editor.setText(text);
    }

    public String getText() {
    	return editor.getText();
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
    		@SuppressWarnings("unused")
			ClojureEditor ced1 = new ClojureEditor();
			@SuppressWarnings("unused")
			ClojureEditor ced2 = new ClojureEditor("Dark", 18);
		});
    }
}
