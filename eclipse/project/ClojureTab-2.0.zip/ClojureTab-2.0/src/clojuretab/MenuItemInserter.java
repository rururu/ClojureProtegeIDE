/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package clojuretab;

import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protege.plugin.AbstractProjectPlugin;
import edu.stanford.smi.protege.ui.ProjectManager;
import edu.stanford.smi.protege.ui.ProjectMenuBar;
import edu.stanford.smi.protege.ui.ProjectToolBar;
import edu.stanford.smi.protege.ui.ProjectView;
import java.awt.event.ActionEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractAction;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

/**
 *
 * @author ru
 */
public class MenuItemInserter extends AbstractProjectPlugin {
	
    public void afterCreate(Project prjct) {
        // do nothing
    }

    public void afterLoad(Project prjct) {
        // do nothing
    }

    public void afterSave(Project prjct) {
        // do nothing
    }

	public void afterShow(ProjectView pv, ProjectToolBar ptb, ProjectMenuBar pmb) {
		JMenu tMenu = pmb.getMenu(1);

		AbstractAction cwAction = new AbstractAction("(start-script)") {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent event) {
				String prj_name = ProjectManager.getProjectManager().getCurrentProject().getName();
				KnowledgeBase kb = ClojureTab.getKb();
				Instance pins = ClojureTab.findForSlotValue(Ontology.PROGRAM, Ontology.TITLE, prj_name);
				if (pins != null) {
		            Instance nsi = (Instance) pins.getOwnSlotValue(kb.getSlot(Ontology.NAMESPACE_S));
		            if(nsi!=null){
		                String ns = (String) nsi.getOwnSlotValue(kb.getSlot(Ontology.TITLE));
						try {
							if (!ClojureTab.isInit()) {
								ClojureTab.initClojure();
							}
							if (!ClojureTab.isReplrun()) {
								ClojureTab.startRepl();
							}
							ClojureActionButton.loadProgram("protege.core");
							ClojureTab.loadProgram(pins);
							ClojureTab.invoke(ns, "start-script");
						} catch (Exception ex) {
							Logger.getLogger(ClojureActionButton.class.getName()).log(Level.SEVERE, null, ex);
						}
					} else {ClojureTab.setStatus("Pamespace instance for program \""+prj_name+"\" not found!");}
				} else {ClojureTab.setStatus("Program \""+prj_name+"\" not found!");}
			}
		};
		
		tMenu.add(new JMenuItem(cwAction));
	}

    public void beforeSave(Project prjct) {
        // do nothing
    }

    public void beforeHide(ProjectView pv, ProjectToolBar ptb, ProjectMenuBar pmb) {
        // do nothing
    }

    public void beforeClose(Project prjct) {
        // do nothing
    }

    public String getName() {
        return "Menu Item Inserter";
    }

    public void dispose() {
        // do nothing
    }

}
