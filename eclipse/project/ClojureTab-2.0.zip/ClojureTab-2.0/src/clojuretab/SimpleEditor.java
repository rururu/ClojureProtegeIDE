package clojuretab;

import javax.swing.*;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.text.*;
import java.awt.*;

public class SimpleEditor {

    private static final AttributeSet DEFAULT_STYLE;
    private static final AttributeSet LEFT_STYLE;
    private static final AttributeSet RIGHT_STYLE;

    static {
        StyleContext sc = StyleContext.getDefaultStyleContext();

        DEFAULT_STYLE = sc.addAttribute(
                sc.getEmptySet(),
                StyleConstants.Foreground,
                Color.BLACK
        );

        LEFT_STYLE = sc.addAttribute(
                sc.getEmptySet(),
                StyleConstants.Foreground,
                Color.RED
        );

        RIGHT_STYLE = sc.addAttribute(
                sc.getEmptySet(),
                StyleConstants.Foreground,
                Color.GREEN
        );
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(SimpleEditor::createUI);
    }

    private static void createUI() {
        JFrame frame = new JFrame("Simple Editor");
        JTextPane pane = new JTextPane();

        pane.addCaretListener(new BracketHighlighter(pane));

        frame.add(new JScrollPane(pane));
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    // =================== Highlighter ===================

    static class BracketHighlighter implements CaretListener {

        private final JTextPane pane;

        BracketHighlighter(JTextPane pane) {
            this.pane = pane;
        }

        @Override
        public void caretUpdate(CaretEvent e) {
            StyledDocument doc = pane.getStyledDocument();
            resetStyles(doc);

            int pos = e.getDot();
            if (pos == 0) return;

            try {
                char ch = doc.getText(pos - 1, 1).charAt(0);

                if (!isBracket(ch)) return;

                int match = findMatchingBracket(doc.getText(0, doc.getLength()), pos - 1, ch);
                if (match == -1) return;

                if (isLeftBracket(ch)) {
                    doc.setCharacterAttributes(pos - 1, 1, LEFT_STYLE, true);
                    doc.setCharacterAttributes(match, 1, RIGHT_STYLE, true);
                } else {
                    doc.setCharacterAttributes(match, 1, LEFT_STYLE, true);
                    doc.setCharacterAttributes(pos - 1, 1, RIGHT_STYLE, true);
                }

            } catch (BadLocationException ignored) {
            }
        }

        private void resetStyles(StyledDocument doc) {
            doc.setCharacterAttributes(0, doc.getLength(), DEFAULT_STYLE, true);
        }
    }

    // =================== Logic ===================

    private static boolean isBracket(char c) {
        return "(){}[]".indexOf(c) >= 0;
    }

    private static boolean isLeftBracket(char c) {
        return c == '(' || c == '{' || c == '[';
    }

    private static char matchingBracket(char c) {
        return switch (c) {
            case '(' -> ')';
            case ')' -> '(';
            case '{' -> '}';
            case '}' -> '{';
            case '[' -> ']';
            case ']' -> '[';
            default -> 0;
        };
    }

    private static int findMatchingBracket(String text, int pos, char ch) {
        char match = matchingBracket(ch);
        int depth = 1;

        if (isLeftBracket(ch)) {
            for (int i = pos + 1; i < text.length(); i++) {
                char c = text.charAt(i);
                if (c == ch) depth++;
                else if (c == match) {
                    depth--;
                    if (depth == 0) return i;
                }
            }
        } else {
            for (int i = pos - 1; i >= 0; i--) {
                char c = text.charAt(i);
                if (c == ch) depth++;
                else if (c == match) {
                    depth--;
                    if (depth == 0) return i;
                }
            }
        }
        return -1;
    }
}
