package clojuretab;

import java.awt.Dimension;
import javax.swing.*;

@SuppressWarnings("serial")
public class SectionEditor extends ClojureEditor {

    public SectionEditor(
    		String text,
    		String type,
    		String label,
    		int numbBegin, 
    		int numbEnd, 
    		String theme,
    		int fontSize,
    		int width,
    		int hight) {
    	super(theme, fontSize);
    	setTitle("SectionEditor: "+type+" "+label+" "+numbBegin+"-"+numbEnd);
    	setStartLineNumber(numbBegin);
    	setText(text);
    	setPreferredSize(new Dimension(width,hight));
    	pack();
    	}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SectionEditor editor = new SectionEditor("abbra\ncaddabra", "type","label", 1, 2, "Light", 14, 480, 320);
            editor.setVisible(true);
        });
    }
}

